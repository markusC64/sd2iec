/*
	Demo-Application LCD-Test        (c) 2004,2005 by Helmut Wallner

	Demonstration for the HAPSIM controls:  LCD, Buttons and LEDs

	LCD:  16x2 chars used in 4-bit IO mode
	      Data-Lines connected to PORTA, Bit 4..7
	      RS pin connected to PORTC, Bit 6
	      RW pin -> PORTG, Bit 0
	      E pin  -> PORTG, Bit 1
	4 Buttons connected to PORTD, Bit 4..7
	8 LEDs connected to PORTB, Bit 0..7
*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include "bool.h"

#ifndef BYTE
typedef unsigned char BYTE;
#endif


#include "lcd.h"

#define DLEFT 0
#define DRIGHT 1

#define CMIN 0x20

static const PROGMEM BYTE copyRightChar[] =
{
	0x07, 0x08, 0x13, 0x14, 0x14, 0x13, 0x08, 0x07,
	0x00, 0x10, 0x08, 0x08, 0x08, 0x08, 0x10, 0x00
};

int main( void )
{
	BYTE is, xor;
	BYTE c1;
	int mode=0;
	int curmode=0;
	int dir=DRIGHT; // 0=right; 1=left
	bool shift = false;
	int dispcol=0;
	int i;

    /* initialize display, cursor off */
    lcd_init(LCD_DISP_ON);

    /* clear display and home cursor */
    lcd_clrscr();

    /* put string to display (line 1) with linefeed */
    lcd_puts_p(PSTR("*** LCD Test ***\n"));

    /* cursor is now on second line, write second line */
    lcd_data(0);
    lcd_data(1);
    lcd_puts_p(PSTR("Helmut Wallner"));

	/* display user defined (c) character */
    lcd_command(_BV(LCD_CGRAM));
    for(i=0; i<16; i++)
    {
    	lcd_data(pgm_read_byte_near(&copyRightChar[i]));
    }

    /* move cursor to position 8 on line 2 */
    lcd_gotoxy(7,0);

    /* write single char to display */
    lcd_putc('-');

	is = PIND;

	DDRB = 0xff;

	c1 = CMIN;
	while(1)
	{
		PORTB = _BV(mode) | (is & 0xf0);

		while((PIND ^ is) == 0);

		xor = PIND ^ is;
		if((xor & 0x10) && !(PIND&0x10))
		{
			curmode++;
			switch(curmode)
			{
			case 1:
				// underlined cursor
			    lcd_command(LCD_DISP_ON_CURSOR);
				break;
			case 2:
				// underlinded and blinking cursor
			    lcd_command(LCD_DISP_ON_CURSOR_BLINK);
				break;
			case 3:
				// blinking cursor
			    lcd_command(LCD_DISP_ON_BLINK);
				break;
			default:
				// cursor off
				curmode = 0;
			    lcd_command(LCD_DISP_ON);
				break;
			}
		}
		else if((xor & 0x20) && !(PIND&0x20))
		{
			mode++;
			switch(mode)
			{
			case 1:
				// cursor movement
				break;

			case 2:
				// display shift
			    break;

			case 3:
				// CGRAM test
			    lcd_clrscr();
			    lcd_command(LCD_ENTRY_INC);
			    dir = DRIGHT;
				for(i=0; i<LCD_DISP_LENGTH; i++)
				{
					lcd_data(i);
				}
			    lcd_gotoxy(3,1);
			    lcd_puts_p(PSTR("CGRAM Test"));
			    lcd_command(_BV(LCD_CGRAM));
				break;

			default:
				// display characters
				mode = 0;
			    lcd_command(_BV(LCD_DDRAM));
			    lcd_command(LCD_ENTRY_INC);
			    dir = DRIGHT;
			    shift = false;
			    dispcol=0;
				break;
			}
		}
		else if(xor & 0xc0)	// left or right
		{
			switch(mode)
			{
			case 1:
				// cursor movement
				if(xor & 0x40) // left
				{
					lcd_command(LCD_MOVE_CURSOR_LEFT);
				}
				else
				{
					lcd_command(LCD_MOVE_CURSOR_RIGHT);
				}
				break;
			case 2:
				// display shift
				if(xor & 0x40) // left
				{
					lcd_command(LCD_MOVE_DISP_LEFT);
				}
				else
				{
					lcd_command(LCD_MOVE_DISP_RIGHT);
				}
				break;
			case 3:
				// CGRAM test
				if(xor & 0x40) // left
				{
					if(dir != DLEFT)
					{
						dir = DLEFT;
						lcd_command(LCD_ENTRY_DEC);
					}
				}
				else
				{
					// right
					if(dir != DRIGHT)
					{
						dir = DRIGHT;
						lcd_command(LCD_ENTRY_INC);
					}
				}
			    lcd_data(c1++);
				break;

			default:
				// display characters
				if(xor & 0x40) // left
				{
					if(dir != DLEFT)
					{
						dir = DLEFT;
						lcd_command(LCD_ENTRY_DEC);
						shift = false;
					}
					if(!shift)
					{
						i = lcd_getxy()%LCD_START_LINE2;
						if(i < dispcol)
							i += LCD_LINE_LENGTH;
						if((i - dispcol) < 1)
						{
							shift = true;
							lcd_command(LCD_ENTRY_DEC_SHIFT);
						}
					}
					if(shift)
					{
						if(dispcol <= 0)
							dispcol += LCD_LINE_LENGTH;
						dispcol--;
					}
				}
				else
				{
					// right
					if(dir != DRIGHT)
					{
						dir = DRIGHT;
						lcd_command(LCD_ENTRY_INC);
						shift = false;
					}
					if(!shift)
					{
						i = lcd_getxy()%LCD_START_LINE2;
						if(i < dispcol)
							i += LCD_LINE_LENGTH;
						if((i - dispcol) > (LCD_DISP_LENGTH-2))
						{
							shift = true;
							lcd_command(LCD_ENTRY_INC_SHIFT);
						}
					}
					if(shift)
					{
						dispcol++;
						if(dispcol >= LCD_LINE_LENGTH)
							dispcol -= LCD_LINE_LENGTH;
					}
				}
			    lcd_data(c1++);
				break;
			}
		}

		is = PIND;
	}
	return 0;
}
